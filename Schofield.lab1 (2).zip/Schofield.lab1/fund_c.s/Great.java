
/**
 * Write a description of class Great here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Great
{
    public static void main(String[] args){
        System.out.println("CPSC is great");
    }
}
