
/**
 * This is the plumbing needed for each and every main class
 *
 * @author Cameron Schofield
 * @version (08/30)
 */
public class plumbing
{
    public static void main (String [] args){
        
    }
}
