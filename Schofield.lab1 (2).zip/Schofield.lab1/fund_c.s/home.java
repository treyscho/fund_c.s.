
/**
 * Write a description of class home here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class home
{
    public static void main(String[] args){
        System.out.println("  /^^^^^^^^^^^\\");
        System.out.println(" /            \\");
        System.out.println("|          _ _  |");
        System.out.println("|         |_|_| |");
        System.out.println("|         |_|_| |");
        System.out.println("|     ____      |");
        System.out.println("|    |   .|     |");
        System.out.println("|    |____|     |");
        System.out.println("-----------------");
    }
}
