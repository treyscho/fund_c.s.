import java.util.Scanner;
/**
 * Write a description of class math here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class math
{
    public static void main(String[] args){
        int f = 5;
        int s = 5;
        System.out.println("the sum of " + f + " " + s + " " + "is" + (f + s));
        System.out.println("the difference of " + f + " " + s  + " " + "is" + (f - s));
        System.out.println("the product of " + f + " " + s+ " " +"is" + (f * s));
        System.out.println("the dividend of " + f + " " + s + " " + "is" + (f / s));
        
    }
}
