
/**
 * Write a description of class Love here.
 *
 * @author (Cameron Schofield)
 * @version (08/30)
 */
public class Love
{
    public static void main(String[] args){
        System.out.println("CPSC is great");
        System.out.println("i love programing");
    }
}
